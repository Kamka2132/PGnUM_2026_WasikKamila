using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class ScoreManager : MonoBehaviour
{
    public int score = 0;
    public int lives = 3;

    public TextMeshProUGUI scoreText;
    public GameObject[] hearts;
    public GameObject gameOverPanel;

    private Spawner spawner;

    void Start()
    {
        spawner = Object.FindFirstObjectByType<Spawner>();
        Time.timeScale = 1f;
        
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        UpdateScoreText();
        UpdateHeartsUI();
    }

    public void AddScore()
    {
        score++;
        UpdateScoreText();
        
        // SYGNAŁ DLA SPAWNERA
        if (spawner != null)
        {
            spawner.IncreaseDifficulty();
        }
    }

    public void LoseLife()
    {
        lives--;
        UpdateHeartsUI();

        if (lives <= 0)
        {
            GameOver();
        }
    }

    void UpdateScoreText()
    {
        if (scoreText != null) scoreText.text = "Punkty: " + score;
    }

    void UpdateHeartsUI()
    {
        for (int i = 0; i < hearts.Length; i++)
        {
            if (hearts[i] != null)
                hearts[i].SetActive(i < lives);
        }
    }

    void GameOver()
    {
        Time.timeScale = 0f;
        if (gameOverPanel != null) gameOverPanel.SetActive(true);
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}