using UnityEngine;
using UnityEngine.InputSystem;

public class Znikniecie_zoledzia : MonoBehaviour
{
    private Camera mainCam;
    private float screenBottom;

    void Start()
    {
        mainCam = Camera.main;
        // Obliczamy spód ekranu, żeby wiedzieć kiedy zabrać życie
        screenBottom = mainCam.ViewportToWorldPoint(new Vector3(0.5f, -0.1f, 0f)).y;
    }

    void Update()
    {
        // KLIKNIĘCIE
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 mousePos = Mouse.current.position.ReadValue();
            Vector3 worldPos = mainCam.ScreenToWorldPoint(new Vector3(mousePos.x, mousePos.y, 10f));
            Vector2 worldPos2D = new Vector2(worldPos.x, worldPos.y);

            Collider2D hit = Physics2D.OverlapPoint(worldPos2D);

            if (hit != null && hit.gameObject == gameObject)
            {
                ScoreManager sm = Object.FindFirstObjectByType<ScoreManager>();
                if (sm != null) sm.AddScore();
                
                Destroy(gameObject);
            }
        }

        // UCIECZKA
        if (transform.position.y < screenBottom)
        {
            ScoreManager sm = Object.FindFirstObjectByType<ScoreManager>();
            if (sm != null) sm.LoseLife();
            
            Destroy(gameObject);
        }
    }
}