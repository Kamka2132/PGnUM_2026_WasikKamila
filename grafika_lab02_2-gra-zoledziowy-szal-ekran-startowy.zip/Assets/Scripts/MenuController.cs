using UnityEngine;
using UnityEngine.SceneManagement; // To jest niezbędne do przełączania scen

public class MenuControler : MonoBehaviour
{
    public void ZacznijGre()
    {
        // Wczytuje scenę o nazwie "SampleScene"
        // Upewnij się, że nazwa w cudzysłowie jest identyczna jak nazwa Twojej sceny!
        SceneManager.LoadScene("SampleScene");
    }
}