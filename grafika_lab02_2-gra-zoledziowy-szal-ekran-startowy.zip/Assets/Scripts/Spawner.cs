using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject zoladzPrefab;

    [Header("Ustawienia Tempa")]
    public float initialSpawnRate = 1.6f;
    public float minSpawnRate = 0.5f;
    public float speedUpAmount = 0.05f;

    [Header("Ustawienia Grawitacji")]
    public float initialGravity = 0.4f;
    public float gravityIncrease = 0.02f;
    public float maxGravity = 1.0f;

    private float currentSpawnRate;
    private float currentGravity;
    private float timer = 0f;

    void Start()
    {
        currentSpawnRate = initialSpawnRate;
        currentGravity = initialGravity;
    }

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= currentSpawnRate)
        {
            Spawn();
            timer = 0f;
        }
    }

    public void IncreaseDifficulty()
    {
        // Przyspieszamy spawn
        if (currentSpawnRate > minSpawnRate)
            currentSpawnRate -= speedUpAmount;

        // Zwiększamy grawitację (szybkość spadania)
        if (currentGravity < maxGravity)
            currentGravity += gravityIncrease;

        Debug.Log($"Trudność UP! Tempo: {currentSpawnRate:F2}, Grawitacja: {currentGravity:F2}");
    }

    void Spawn()
    {
        Camera cam = Camera.main;
        float screenTop = cam.ViewportToWorldPoint(new Vector3(0.5f, 1.1f, 0f)).y;
        float screenLeft = cam.ViewportToWorldPoint(new Vector3(0.1f, 0f, 0f)).x;
        float screenRight = cam.ViewportToWorldPoint(new Vector3(0.9f, 0f, 0f)).x;

        float randomX = Random.Range(screenLeft, screenRight);
        Vector3 spawnPos = new Vector3(randomX, screenTop, 0f);

        GameObject nowyZoladz = Instantiate(zoladzPrefab, spawnPos, Quaternion.identity);
        
        // PRZEKAZANIE AKTUALNEJ GRAWITACJI DO NOWEGO ŻOŁĘDZIA
        Rigidbody2D rb = nowyZoladz.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.gravityScale = currentGravity;
        }
    }
}