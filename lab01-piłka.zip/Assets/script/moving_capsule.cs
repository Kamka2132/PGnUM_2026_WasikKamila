using UnityEngine;

public class MovingObject : MonoBehaviour
{
    public Vector3 startPos; // Punkt startowy
    public float distance = 5f; // Jak daleko ma się przesuwać
    public float speed = 2f;    // Prędkość ruchu

    void Start()
    {
        // Zapamiętujemy pozycję, w której postawiliśmy kapsułę w edytorze
        startPos = transform.position;
    }

    void Update()
    {
        // Obliczamy przesunięcie (od 0 do distance)
        float movement = Mathf.PingPong(Time.time * speed, distance);
        
        // Aktualizujemy pozycję na osi X (możesz zmienić na Z, jeśli wolisz)
        transform.position = startPos + new Vector3(movement, 0, 0);
    }
}