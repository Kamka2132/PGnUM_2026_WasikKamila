using UnityEngine;

public class BallDestroyer : MonoBehaviour
{

    void OnMouseDown()
    {
        Destroy(gameObject);
    }
}