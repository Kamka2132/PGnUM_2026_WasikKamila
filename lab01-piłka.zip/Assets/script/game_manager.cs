using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject ballPrefab;
    public Transform spawnPoint;
    public float interval = 3f; // Czas w sekundach między spawnem

    private float timer;

    void Start()
    {
        SpawnNewBall();
        timer = interval; // Ustawienie licznika na start
    }

    void Update()
    {
        // Odliczanie czasu
        timer -= Time.deltaTime;

        if (timer <= 0f)
        {
            SpawnNewBall();
            timer = interval; // Resetowanie licznika do 5 sekund
        }
    }

    public void SpawnNewBall()
    {
        Instantiate(ballPrefab, spawnPoint.position, Quaternion.identity);
    }
}