using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject zoladzPrefab;
    
    public float initialSpawnRate = 2.0f; 
    public float minSpawnRate = 0.6f;     // Podniesiony limit, żeby nie zasypało
    public float speedUpAmount = 0.02f;   // Mniejsza wartość = łagodniejsze przyspieszanie

    private float currentSpawnRate;
    private float timer = 0f;

    void Start()
    {
        currentSpawnRate = initialSpawnRate;
    }

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= currentSpawnRate)
        {
            Spawn();
            timer = 0f;
        }
    }

    // Tę funkcję będziemy wywoływać ze skryptu ScoreManager przy każdym punkcie!
    public void IncreaseDifficulty()
    {
        if (currentSpawnRate > minSpawnRate)
        {
            currentSpawnRate -= speedUpAmount;
            Debug.Log("Nowe tempo: " + currentSpawnRate);
        }
    }

    void Spawn()
    {
        float randomX = Random.Range(-8f, 8f);
        Vector3 spawnPos = new Vector3(randomX, 6f, 0f);
        Instantiate(zoladzPrefab, spawnPos, Quaternion.identity);
    }
}