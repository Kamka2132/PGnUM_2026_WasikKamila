using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScoreManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    public Image[] hearts;
    public GameObject gameOverPanel; // Miejsce na nasz Panel z napisem

    private int score = 0;
    private int misses = 0;
    private bool isGameOver = false;

    void Start()
    {
        // Na wszelki wypadek upewniamy się, że panel jest ukryty na starcie
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
    }

    public void AddPoint()
    {
        if (isGameOver) return; // Nie dodawaj punktów po przegranej
        score++;
        scoreText.text = "Punkty: " + score;

        Spawner spawner = Object.FindFirstObjectByType<Spawner>();
        if (spawner != null) spawner.IncreaseDifficulty();
    }

    public void MissedZoladz()
    {
        if (isGameOver) return;

        if (misses < hearts.Length)
        {
            hearts[misses].gameObject.SetActive(false);
            misses++;
        }

        if (misses >= hearts.Length)
        {
            GameOver();
        }
    }

    void GameOver()
    {
        isGameOver = true;
        Debug.Log("KONIEC GRY!");
        
        // Pokazujemy panel "Koniec Gry"
        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(true);
        }

        // Zatrzymujemy czas w grze (żołędzie przestaną spadać)
        Time.timeScale = 0f;
    }

    // Tę funkcję przypiszemy do przycisku "Zagraj ponownie"
    public void RestartGame()
    {
        Time.timeScale = 1f; // Przywracamy czas przed restartem!
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}