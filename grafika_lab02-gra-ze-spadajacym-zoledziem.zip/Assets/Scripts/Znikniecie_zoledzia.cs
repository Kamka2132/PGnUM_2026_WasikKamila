using UnityEngine;
using UnityEngine.InputSystem; // Wymagane dla Unity 6 i nowego Input Systemu

public class Znikniecie_zoledzia : MonoBehaviour
{
    private Camera mainCam;

    void Start()
    {
        // Przypisujemy kamerę raz na początku, żeby zaoszczędzić zasoby
        mainCam = Camera.main;
    }

    void Update()
    {
        // 1. WYKRYWANIE KLIKNIĘCIA
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            // Pobieramy pozycję myszy i zamieniamy ją na punkt w świecie 2D
            Vector2 mouseScreenPos = Mouse.current.position.ReadValue();
            Vector3 mouseWorldPos = mainCam.ScreenToWorldPoint(new Vector3(mouseScreenPos.x, mouseScreenPos.y, Mathf.Abs(mainCam.transform.position.z)));
            Vector2 mouseWorldPos2D = new Vector2(mouseWorldPos.x, mouseWorldPos.y);

            // Sprawdzamy, czy w tym punkcie jest collider tego konkretnego żołędzia
            Collider2D hitCollider = Physics2D.OverlapPoint(mouseWorldPos2D);

            if (hitCollider != null && hitCollider.gameObject == gameObject)
            {
                // Znajdujemy ScoreManager (używamy nowej metody dla Unity 6)
                ScoreManager sm = Object.FindFirstObjectByType<ScoreManager>();
                
                if (sm != null) 
                {
                    sm.AddPoint(); // Dodaje punkt i przyspiesza spawner
                }

                Debug.Log("Trafiono żołędzia!");
                Destroy(gameObject);
            }
        }

        // 2. WYKRYWANIE UCIECZKI (SPADNIĘCIE POZA EKRAN)
        // Jeśli żołądź spadnie poniżej -6 (dostosuj tę wartość do swojej kamery)
        if (transform.position.y < -6f)
        {
            ScoreManager sm = Object.FindFirstObjectByType<ScoreManager>();
            
            if (sm != null)
            {
                sm.MissedZoladz(); // Zabiera serduszko
            }

            Debug.Log("Żołądź uciekł! Straciłeś życie.");
            Destroy(gameObject);
        }
    }
}